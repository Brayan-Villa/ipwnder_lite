#ifndef ASM64_H
#define ASM64_H

#define INSN_MOVZ_W1_1      0x52800021
#define INSN_STRB_W1_SP_248 0x3903e3e1
#define INSN_STRB_W1_SP_249 0x3903e7e1
#define INSN_STRB_W1_SP_250 0x3903ebe1
#define INSN_STRB_W1_SP_251 0x3903efe1
#define INSN_STRB_W1_SP_252 0x3903f3e1
#define INSN_STRB_W1_SP_253 0x3903f7e1
#define INSN_STRB_W1_SP_254 0x3903fbe1
#define INSN_MOVZ_X0_0      0xd2800000
#define INSN_RET            0xd65f03c0
#define INSN_NOP            0xd503201f

#endif
